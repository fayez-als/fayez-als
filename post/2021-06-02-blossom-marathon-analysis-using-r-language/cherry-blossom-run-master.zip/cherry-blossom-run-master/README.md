# cherry-blossom-run
Modeling Run Times in the Cherry Blossom Race (from Data Science in R book by Nolan and Temple Lang)
